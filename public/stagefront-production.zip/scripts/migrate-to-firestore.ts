/**
 * StageFront Events — Safe Firestore Data Migration Script
 *
 * Usage (after configuring FIREBASE_SERVICE_ACCOUNT_KEY or GOOGLE_APPLICATION_CREDENTIALS in .env):
 *   npx tsx scripts/migrate-to-firestore.ts
 *
 * Behavior:
 * - Verifies that valid Firebase Admin service-account credentials are configured.
 * - Idempotently migrates INITIAL_EVENTS into `/events/{eventId}` (skips events that already exist unless --force is passed).
 * - Initializes the nested `/events/{eventId}/seats/{seatId}` subcollection (160 seats per event) in Firestore batches,
 *   preserving any existing seat documents so active holds or confirmed bookings are never overwritten.
 */

import 'dotenv/config';
import fs from 'fs';
import { initializeApp, cert, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { INITIAL_EVENTS, generateEventSeatMap } from '../src/data/seedData.ts';

async function migrateToFirestore() {
  const projId = process.env.FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID || 'stagefront-events';

  let app;
  if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
    const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
    app = initializeApp({
      credential: cert(sa),
      projectId: sa.project_id || projId,
    });
  } else if (process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY) {
    app = initializeApp({
      credential: cert({
        projectId: projId,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
      }),
      projectId: projId,
    });
  } else if (
    process.env.GOOGLE_APPLICATION_CREDENTIALS &&
    fs.existsSync(process.env.GOOGLE_APPLICATION_CREDENTIALS)
  ) {
    app = initializeApp({
      credential: applicationDefault(),
      projectId: projId,
    });
  } else {
    console.error(
      '[Migration Aborted] No Firebase Admin service-account credentials found.\n' +
        'Set FIREBASE_SERVICE_ACCOUNT_KEY or GOOGLE_APPLICATION_CREDENTIALS in .env before running migration.'
    );
    process.exit(1);
  }

  const db = getFirestore(app);
  console.log(`[StageFront Migration] Connected to Firestore project: ${projId}`);

  for (const event of INITIAL_EVENTS) {
    const eventRef = db.collection('events').doc(event.id);
    const existingEventSnap = await eventRef.get();

    const seats = generateEventSeatMap(event.id, event.tierConfigs);
    const seatsCol = eventRef.collection('seats');
    const existingSeatsSnap = await seatsCol.get();

    if (!existingEventSnap.exists) {
      const availableCount = seats.filter((s) => s.status === 'available').length;
      await eventRef.set({
        ...event,
        totalSeats: seats.length,
        availableSeats: availableCount,
      });
      console.log(`  [+] Created event document: /events/${event.id} (${event.title})`);
    } else {
      console.log(`  [=] Preserved existing event document: /events/${event.id}`);
    }

    if (existingSeatsSnap.empty) {
      const batch = db.batch();
      for (const seat of seats) {
        batch.set(seatsCol.doc(seat.id), seat);
      }
      await batch.commit();
      console.log(`      -> Seeded ${seats.length} seats in /events/${event.id}/seats`);
    } else {
      console.log(
        `      -> Preserved ${existingSeatsSnap.size} existing seats in /events/${event.id}/seats`
      );
    }
  }

  console.log('[StageFront Migration] Migration completed safely.');
}

migrateToFirestore().catch((err) => {
  console.error('[StageFront Migration] Failed:', err);
  process.exit(1);
});
